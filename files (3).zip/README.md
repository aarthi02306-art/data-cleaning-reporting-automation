# Data Cleaning & Reporting Automation

Python script that automatically cleans a messy CSV file and generates an HTML report with charts.

## What it does
- Standardizes column names, trims spaces, fixes text case (e.g. `chennai `, `CHENNAI`, `Chenai` -> `Chennai`)
- Converts bad values (`N/A`) to proper numbers and parses mixed date formats
- Removes duplicate rows
- Handles missing values (median for numbers, `Unknown` for text)
- Creates `cleaned_data.csv` and `report.html` (KPIs, cleaning summary, 3 charts)

## How to run
```
pip install -r requirements.txt
python clean_and_report.py                  # creates sample messy data and runs
python clean_and_report.py --input my.csv   # use your own CSV
```

## Output
- `cleaned_data.csv` - cleaned dataset
- `report.html` - open in browser (or print to PDF)

## Tech
Python, pandas, matplotlib
